# frozen_string_literal: true

module Skippy
  puts "RUBY_PLATFORM=#{RUBY_PLATFORM}"

  if RUBY_PLATFORM =~ /darwin/
    require 'skippy/os/mac'
    OS = Skippy::OSMac
  elsif RUBY_PLATFORM =~ /x86_64-linux-gnu/
    require 'skippy/os/wine'
    puts 'linux wine platform found !'
    OS = Skippy::OSWine
  else
    require 'skippy/os/win'
    OS = Skippy::OSWin
  end

  @os = OS.new

  def self.os
    @os
  end

end
